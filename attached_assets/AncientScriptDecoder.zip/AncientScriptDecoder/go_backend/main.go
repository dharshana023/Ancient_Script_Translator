package main

import (
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"sync"
	"syscall"
	"time"

	"ancient-script-translator/api"
	"ancient-script-translator/data_structures"
)

// Global variables
var (
	jobQueue *data_structures.Queue
	wg       sync.WaitGroup
)

// worker processes jobs from the queue
func worker(id int, jobs <-chan interface{}) {
	defer wg.Done()
	
	log.Printf("Worker %d started", id)
	
	for job := range jobs {
		// Process the job
		log.Printf("Worker %d processing job: %v", id, job)
		
		// Simulate work with some delay
		time.Sleep(500 * time.Millisecond)
	}
	
	log.Printf("Worker %d stopped", id)
}

// startWorkerPool initializes and starts a pool of worker goroutines
func startWorkerPool(numWorkers int) chan<- interface{} {
	jobChan := make(chan interface{}, 100)
	
	// Start workers
	for i := 1; i <= numWorkers; i++ {
		wg.Add(1)
		go worker(i, jobChan)
	}
	
	return jobChan
}

// setupJobQueue initializes the job queue
func setupJobQueue() {
	jobQueue = data_structures.NewQueue()
}

// jobProcessor continually processes jobs from the queue
func jobProcessor(jobChan chan<- interface{}) {
	ticker := time.NewTicker(200 * time.Millisecond)
	defer ticker.Stop()
	
	for range ticker.C {
		// Check if there are jobs in the queue
		if !jobQueue.IsEmpty() {
			// Get a job from the queue
			job, err := jobQueue.Dequeue()
			if err != nil {
				log.Printf("Error dequeuing job: %v", err)
				continue
			}
			
			// Send the job to a worker
			jobChan <- job
		}
	}
}

func main() {
	// Initialize job queue
	setupJobQueue()
	
	// Start worker pool with 3 workers
	jobChan := startWorkerPool(3)
	
	// Start job processor
	go jobProcessor(jobChan)
	
	// Configure the server with middlewares
	port := 8000
	router := api.SetupRoutes()
	
	// Create a server with a reasonable timeout
	server := &http.Server{
		Addr:         fmt.Sprintf("0.0.0.0:%d", port),
		Handler:      router,
		ReadTimeout:  10 * time.Second,
		WriteTimeout: 10 * time.Second,
		IdleTimeout:  120 * time.Second,
	}
	
	// Channel to listen for interrupt signals
	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Interrupt, syscall.SIGTERM)
	
	// Start the server in a goroutine
	go func() {
		log.Printf("Server running on port %d...", port)
		if err := server.ListenAndServe(); err != http.ErrServerClosed {
			log.Fatalf("Server error: %v", err)
		}
	}()
	
	// Wait for interrupt signal
	<-stop
	log.Println("Shutting down server...")
	
	// Add some cleanup jobs to demonstrate the queue
	for i := 1; i <= 5; i++ {
		jobQueue.Enqueue(fmt.Sprintf("Cleanup task %d", i))
	}
	
	// Wait for all jobs to complete (with a timeout)
	done := make(chan struct{})
	go func() {
		wg.Wait()
		close(done)
	}()
	
	// Either wait for jobs to complete or timeout
	select {
	case <-done:
		log.Println("All workers finished")
	case <-time.After(5 * time.Second):
		log.Println("Timeout waiting for workers to finish")
	}
	
	log.Println("Server shutdown complete")
}
