package data_structures

import (
	"errors"
	"sync"
)

// Queue is a thread-safe FIFO queue
type Queue struct {
	items []interface{}
	mu    sync.Mutex
}

// NewQueue creates a new empty queue
func NewQueue() *Queue {
	return &Queue{
		items: make([]interface{}, 0),
	}
}

// Enqueue adds an item to the end of the queue
func (q *Queue) Enqueue(item interface{}) {
	q.mu.Lock()
	defer q.mu.Unlock()
	
	q.items = append(q.items, item)
}

// Dequeue removes and returns the item at the front of the queue
func (q *Queue) Dequeue() (interface{}, error) {
	q.mu.Lock()
	defer q.mu.Unlock()
	
	if len(q.items) == 0 {
		return nil, errors.New("queue is empty")
	}
	
	// Get the first item
	item := q.items[0]
	
	// Remove it from the queue
	q.items = q.items[1:]
	
	return item, nil
}

// Peek returns the item at the front of the queue without removing it
func (q *Queue) Peek() (interface{}, error) {
	q.mu.Lock()
	defer q.mu.Unlock()
	
	if len(q.items) == 0 {
		return nil, errors.New("queue is empty")
	}
	
	return q.items[0], nil
}

// IsEmpty returns true if the queue is empty
func (q *Queue) IsEmpty() bool {
	q.mu.Lock()
	defer q.mu.Unlock()
	
	return len(q.items) == 0
}

// Size returns the number of items in the queue
func (q *Queue) Size() int {
	q.mu.Lock()
	defer q.mu.Unlock()
	
	return len(q.items)
}

// Clear removes all items from the queue
func (q *Queue) Clear() {
	q.mu.Lock()
	defer q.mu.Unlock()
	
	q.items = make([]interface{}, 0)
}
