package data_structures

import (
	"errors"
	"sync"
)

// PriorityQueue is a thread-safe priority queue implementation
type PriorityQueue struct {
	items []*PriorityItem
	mu    sync.Mutex
}

// PriorityItem represents an item with a priority in the queue
type PriorityItem struct {
	Value    interface{}
	Priority int
}

// NewPriorityQueue creates a new empty priority queue
func NewPriorityQueue() *PriorityQueue {
	return &PriorityQueue{
		items: make([]*PriorityItem, 0),
	}
}

// Enqueue adds an item to the priority queue
func (pq *PriorityQueue) Enqueue(value interface{}, priority int) {
	pq.mu.Lock()
	defer pq.mu.Unlock()
	
	item := &PriorityItem{
		Value:    value,
		Priority: priority,
	}
	
	// If the queue is empty, just add the item
	if len(pq.items) == 0 {
		pq.items = append(pq.items, item)
		return
	}
	
	// Find the position to insert the new item based on priority
	// Higher priority values are inserted first
	var insertIndex int
	for insertIndex = 0; insertIndex < len(pq.items); insertIndex++ {
		if priority > pq.items[insertIndex].Priority {
			break
		}
	}
	
	// Insert the item at the found position
	pq.items = append(pq.items, nil) // Extend the slice by one
	copy(pq.items[insertIndex+1:], pq.items[insertIndex:])
	pq.items[insertIndex] = item
}

// Dequeue removes and returns the highest priority item
func (pq *PriorityQueue) Dequeue() (interface{}, int, error) {
	pq.mu.Lock()
	defer pq.mu.Unlock()
	
	if len(pq.items) == 0 {
		return nil, 0, errors.New("priority queue is empty")
	}
	
	// Get the highest priority item
	item := pq.items[0]
	
	// Remove it from the queue
	pq.items = pq.items[1:]
	
	return item.Value, item.Priority, nil
}

// Peek returns the highest priority item without removing it
func (pq *PriorityQueue) Peek() (interface{}, int, error) {
	pq.mu.Lock()
	defer pq.mu.Unlock()
	
	if len(pq.items) == 0 {
		return nil, 0, errors.New("priority queue is empty")
	}
	
	item := pq.items[0]
	return item.Value, item.Priority, nil
}

// IsEmpty returns true if the priority queue is empty
func (pq *PriorityQueue) IsEmpty() bool {
	pq.mu.Lock()
	defer pq.mu.Unlock()
	
	return len(pq.items) == 0
}

// Size returns the number of items in the priority queue
func (pq *PriorityQueue) Size() int {
	pq.mu.Lock()
	defer pq.mu.Unlock()
	
	return len(pq.items)
}

// Clear removes all items from the priority queue
func (pq *PriorityQueue) Clear() {
	pq.mu.Lock()
	defer pq.mu.Unlock()
	
	pq.items = make([]*PriorityItem, 0)
}

// UpdatePriority changes the priority of a specific item
// Returns true if the item was found and updated
func (pq *PriorityQueue) UpdatePriority(matchFunc func(interface{}) bool, newPriority int) bool {
	pq.mu.Lock()
	defer pq.mu.Unlock()
	
	// Find the item
	for i, item := range pq.items {
		if matchFunc(item.Value) {
			// Remove the item
			value := item.Value
			pq.items = append(pq.items[:i], pq.items[i+1:]...)
			
			// Re-add it with the new priority
			pq.mu.Unlock() // Unlock before recursive call
			pq.Enqueue(value, newPriority)
			pq.mu.Lock() // Lock again
			
			return true
		}
	}
	
	return false
}
