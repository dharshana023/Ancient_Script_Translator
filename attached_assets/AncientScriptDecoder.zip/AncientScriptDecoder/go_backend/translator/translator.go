package translator

import (
	"errors"
	"fmt"
	"sync"
	"time"
)

// TranslationResult represents the result of a translation
type TranslationResult struct {
	OriginalText   string            `json:"original_text"`
	TranslatedText string            `json:"translated_text"`
	Confidence     float64           `json:"confidence"`
	ProcessingTime int64             `json:"processing_time_ms"`
	Metadata       map[string]string `json:"metadata"`
}

// Translator interface defines methods all translators must implement
type Translator interface {
	GetName() string
	GetLanguages() []string
	Translate(text string) (*TranslationResult, error)
}

// TranslatorRegistry manages available translator instances
type TranslatorRegistry struct {
	translators map[string]Translator
	mu          sync.RWMutex
}

// NewTranslatorRegistry creates a new translator registry
func NewTranslatorRegistry() *TranslatorRegistry {
	return &TranslatorRegistry{
		translators: make(map[string]Translator),
	}
}

// Register adds a translator to the registry
func (r *TranslatorRegistry) Register(translator Translator) {
	r.mu.Lock()
	defer r.mu.Unlock()
	
	r.translators[translator.GetName()] = translator
}

// Get retrieves a translator by name
func (r *TranslatorRegistry) Get(name string) (Translator, error) {
	r.mu.RLock()
	defer r.mu.RUnlock()
	
	translator, ok := r.translators[name]
	if !ok {
		return nil, fmt.Errorf("translator '%s' not found", name)
	}
	
	return translator, nil
}

// GetAll returns all registered translators
func (r *TranslatorRegistry) GetAll() []Translator {
	r.mu.RLock()
	defer r.mu.RUnlock()
	
	translators := make([]Translator, 0, len(r.translators))
	for _, t := range r.translators {
		translators = append(translators, t)
	}
	
	return translators
}

// MockTranslator is a simple translator for testing purposes
type MockTranslator struct {
	name      string
	languages []string
}

// NewMockTranslator creates a new mock translator
func NewMockTranslator() *MockTranslator {
	return &MockTranslator{
		name:      "MockTranslator",
		languages: []string{"Ancient Greek", "Latin", "Hieroglyphics", "Cuneiform"},
	}
}

// GetName returns the translator name
func (t *MockTranslator) GetName() string {
	return t.name
}

// GetLanguages returns supported languages
func (t *MockTranslator) GetLanguages() []string {
	return t.languages
}

// Translate performs mock translation
func (t *MockTranslator) Translate(text string) (*TranslationResult, error) {
	if text == "" {
		return nil, errors.New("empty text provided")
	}
	
	// Simulate processing time
	startTime := time.Now()
	time.Sleep(300 * time.Millisecond)
	processingTime := time.Since(startTime).Milliseconds()
	
	// Generate a mock translation
	translatedText := fmt.Sprintf("[TRANSLATION] %s", text)
	
	return &TranslationResult{
		OriginalText:   text,
		TranslatedText: translatedText,
		Confidence:     0.85,
		ProcessingTime: processingTime,
		Metadata: map[string]string{
			"model":    "mock-v1",
			"language": "Ancient Script",
		},
	}, nil
}

// GRPCTranslator uses gRPC to communicate with the translation service
type GRPCTranslator struct {
	name      string
	languages []string
	endpoint  string
}

// NewGRPCTranslator creates a new gRPC-based translator
func NewGRPCTranslator(endpoint string) *GRPCTranslator {
	return &GRPCTranslator{
		name:      "GRPCTranslator",
		languages: []string{"Ancient Greek", "Latin", "Hieroglyphics", "Cuneiform"},
		endpoint:  endpoint,
	}
}

// GetName returns the translator name
func (t *GRPCTranslator) GetName() string {
	return t.name
}

// GetLanguages returns supported languages
func (t *GRPCTranslator) GetLanguages() []string {
	return t.languages
}

// Translate performs translation via gRPC
func (t *GRPCTranslator) Translate(text string) (*TranslationResult, error) {
	if text == "" {
		return nil, errors.New("empty text provided")
	}
	
	// TODO: Implement actual gRPC client call
	// This is a placeholder implementation
	startTime := time.Now()
	time.Sleep(500 * time.Millisecond) // Simulate network latency
	processingTime := time.Since(startTime).Milliseconds()
	
	// Generate a mock translation
	translatedText := fmt.Sprintf("[GRPC TRANSLATION] %s", text)
	
	return &TranslationResult{
		OriginalText:   text,
		TranslatedText: translatedText,
		Confidence:     0.92,
		ProcessingTime: processingTime,
		Metadata: map[string]string{
			"model":    "grpc-model-v2",
			"language": "Ancient Script",
			"endpoint": t.endpoint,
		},
	}, nil
}
