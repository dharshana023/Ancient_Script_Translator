package image_processor

import (
	"bytes"
	"errors"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"image/jpeg"
	"image/png"
	"math"
	"strings"
)

// ProcessImage applies the specified algorithm to the input image
// Returns processed image bytes and an error
func ProcessImage(imageBytes []byte, algorithm string, params map[string]interface{}) ([]byte, error) {
	// Decode the input image
	img, format, err := image.Decode(bytes.NewReader(imageBytes))
	if err != nil {
		return nil, fmt.Errorf("failed to decode image: %v", err)
	}
	
	// Process the image based on the algorithm
	var processedImg image.Image
	switch strings.ToLower(algorithm) {
	case "grayscale":
		processedImg = applyGrayscale(img)
	case "rotate":
		angle, ok := getFloatParam(params, "angle", 0.0)
		if !ok {
			return nil, errors.New("missing or invalid angle parameter")
		}
		processedImg = applyRotation(img, angle)
	case "rotate_shear":
		angle, ok := getFloatParam(params, "angle", 0.0)
		if !ok {
			return nil, errors.New("missing or invalid angle parameter")
		}
		processedImg = applyRotationShear(img, angle)
	case "flip":
		processedImg = applyFlip(img)
	case "box_blur":
		radius, ok := getIntParam(params, "radius", 3)
		if !ok {
			return nil, errors.New("missing or invalid radius parameter")
		}
		processedImg = applyBoxBlur(img, radius)
	case "gaussian_blur":
		sigma, ok := getFloatParam(params, "sigma", 1.0)
		if !ok {
			return nil, errors.New("missing or invalid sigma parameter")
		}
		processedImg = applyGaussianBlur(img, sigma)
	case "edge_detection":
		processedImg = applySobelEdgeDetection(img)
	default:
		return nil, fmt.Errorf("unsupported algorithm: %s", algorithm)
	}
	
	// Encode the processed image
	var buf bytes.Buffer
	
	// Always encode as JPEG for consistency
	encodingOpts := jpeg.Options{Quality: 90}
	if err := jpeg.Encode(&buf, processedImg, &encodingOpts); err != nil {
		return nil, fmt.Errorf("failed to encode processed image: %v", err)
	}
	
	// For PNG, we could retain the original format, but JPEG is more efficient for this use case
	// if format == "png" {
	//     if err := png.Encode(&buf, processedImg); err != nil {
	//         return nil, fmt.Errorf("failed to encode processed image: %v", err)
	//     }
	// } else {
	//     // Default to JPEG for other formats
	//     encodingOpts := jpeg.Options{Quality: 90}
	//     if err := jpeg.Encode(&buf, processedImg, &encodingOpts); err != nil {
	//         return nil, fmt.Errorf("failed to encode processed image: %v", err)
	//     }
	// }
	
	return buf.Bytes(), nil
}

// Helper functions for parameter extraction
func getFloatParam(params map[string]interface{}, name string, defaultValue float64) (float64, bool) {
	if params == nil {
		return defaultValue, true
	}
	
	val, ok := params[name]
	if !ok {
		return defaultValue, true
	}
	
	switch v := val.(type) {
	case float64:
		return v, true
	case float32:
		return float64(v), true
	case int:
		return float64(v), true
	default:
		return defaultValue, false
	}
}

func getIntParam(params map[string]interface{}, name string, defaultValue int) (int, bool) {
	if params == nil {
		return defaultValue, true
	}
	
	val, ok := params[name]
	if !ok {
		return defaultValue, true
	}
	
	switch v := val.(type) {
	case int:
		return v, true
	case float64:
		return int(v), true
	case float32:
		return int(v), true
	default:
		return defaultValue, false
	}
}

// Image processing functions

// applyGrayscale converts image to grayscale
func applyGrayscale(img image.Image) image.Image {
	bounds := img.Bounds()
	grayImg := image.NewGray(bounds)
	
	for y := bounds.Min.Y; y < bounds.Max.Y; y++ {
		for x := bounds.Min.X; x < bounds.Max.X; x++ {
			pixel := img.At(x, y)
			grayImg.Set(x, y, pixel)
		}
	}
	
	return grayImg
}

// applyRotation rotates the image by the given angle (degrees)
func applyRotation(img image.Image, angleDeg float64) image.Image {
	// Convert angle to radians
	angle := angleDeg * math.Pi / 180.0
	
	// Original dimensions
	bounds := img.Bounds()
	width, height := bounds.Dx(), bounds.Dy()
	
	// Calculate the dimensions of the new image to fit the rotated content
	cosA, sinA := math.Abs(math.Cos(angle)), math.Abs(math.Sin(angle))
	newWidth := int(math.Ceil(float64(width)*cosA + float64(height)*sinA))
	newHeight := int(math.Ceil(float64(width)*sinA + float64(height)*cosA))
	
	// Create a new image with the calculated dimensions
	rotatedImg := image.NewRGBA(image.Rect(0, 0, newWidth, newHeight))
	
	// Center points
	centerX, centerY := float64(width)/2, float64(height)/2
	newCenterX, newCenterY := float64(newWidth)/2, float64(newHeight)/2
	
	// Apply rotation to each pixel
	for y := 0; y < newHeight; y++ {
		for x := 0; x < newWidth; x++ {
			// Translate to origin
			dx := float64(x) - newCenterX
			dy := float64(y) - newCenterY
			
			// Apply rotation
			srcX := dx*math.Cos(-angle) - dy*math.Sin(-angle) + centerX
			srcY := dx*math.Sin(-angle) + dy*math.Cos(-angle) + centerY
			
			// Check if the source pixel is within the original image bounds
			if srcX >= 0 && srcX < float64(width) && srcY >= 0 && srcY < float64(height) {
				// Get the color at the source position
				pixel := img.At(int(srcX), int(srcY))
				rotatedImg.Set(x, y, pixel)
			}
		}
	}
	
	return rotatedImg
}

// applyRotationShear rotates the image using three shear transformations
func applyRotationShear(img image.Image, angleDeg float64) image.Image {
	// Convert angle to radians
	angle := angleDeg * math.Pi / 180.0
	
	// Calculate shear parameters
	tanHalfAngle := math.Tan(angle / 2)
	sinAngle := math.Sin(angle)
	
	// Original dimensions
	bounds := img.Bounds()
	width, height := bounds.Dx(), bounds.Dy()
	
	// Calculate new dimensions
	cosA, sinA := math.Abs(math.Cos(angle)), math.Abs(math.Sin(angle))
	newWidth := int(math.Ceil(float64(width)*cosA + float64(height)*sinA))
	newHeight := int(math.Ceil(float64(width)*sinA + float64(height)*cosA))
	
	// Create intermediate images
	intermediate1 := image.NewRGBA(image.Rect(0, 0, width, newHeight))
	intermediate2 := image.NewRGBA(image.Rect(0, 0, newWidth, newHeight))
	rotatedImg := image.NewRGBA(image.Rect(0, 0, newWidth, newHeight))
	
	// Center points
	centerX, centerY := float64(width)/2, float64(height)/2
	newCenterX, newCenterY := float64(newWidth)/2, float64(newHeight)/2
	
	// First shear (horizontal)
	for y := 0; y < height; y++ {
		for x := 0; x < width; x++ {
			// Calculate new position
			dy := float64(y) - centerY
			newX := int(float64(x) - dy*tanHalfAngle)
			newY := y
			
			// Adjust for new center
			newX = newX + int(newCenterX-centerX)
			newY = newY + int(newCenterY-centerY)
			
			// Set pixel if within bounds
			if newX >= 0 && newX < width && newY >= 0 && newY < newHeight {
				intermediate1.Set(newX, newY, img.At(x, y))
			}
		}
	}
	
	// Second shear (vertical)
	for y := 0; y < newHeight; y++ {
		for x := 0; x < width; x++ {
			// Calculate new position
			dx := float64(x) - centerX
			newX := x
			newY := int(float64(y) - dx*sinAngle)
			
			// Set pixel if within bounds
			if newX >= 0 && newX < newWidth && newY >= 0 && newY < newHeight {
				intermediate2.Set(newX, newY, intermediate1.At(x, y))
			}
		}
	}
	
	// Third shear (horizontal)
	for y := 0; y < newHeight; y++ {
		for x := 0; x < newWidth; x++ {
			// Calculate new position
			dy := float64(y) - newCenterY
			newX := int(float64(x) - dy*tanHalfAngle)
			newY := y
			
			// Set pixel if within bounds
			if newX >= 0 && newX < newWidth && newY >= 0 && newY < newHeight {
				if intermediate2.At(x, y) != color.RGBA{} {
					rotatedImg.Set(newX, newY, intermediate2.At(x, y))
				}
			}
		}
	}
	
	return rotatedImg
}

// applyFlip flips the image upside down
func applyFlip(img image.Image) image.Image {
	bounds := img.Bounds()
	flippedImg := image.NewRGBA(bounds)
	
	for y := bounds.Min.Y; y < bounds.Max.Y; y++ {
		// Calculate the flipped y-coordinate
		flippedY := bounds.Max.Y - 1 - y + bounds.Min.Y
		
		for x := bounds.Min.X; x < bounds.Max.X; x++ {
			flippedImg.Set(x, flippedY, img.At(x, y))
		}
	}
	
	return flippedImg
}

// applyBoxBlur applies a box blur filter with the given radius
func applyBoxBlur(img image.Image, radius int) image.Image {
	bounds := img.Bounds()
	blurredImg := image.NewRGBA(bounds)
	
	// Copy the image first
	draw.Draw(blurredImg, bounds, img, bounds.Min, draw.Src)
	
	// Apply horizontal blur
	for y := bounds.Min.Y; y < bounds.Max.Y; y++ {
		// Create accumulator for each channel
		var rSum, gSum, bSum, aSum, count int
		
		// Initialize with first pixel
		for i := bounds.Min.X; i <= bounds.Min.X+radius && i < bounds.Max.X; i++ {
			r, g, b, a := getRGBA(img.At(i, y))
			rSum += int(r)
			gSum += int(g)
			bSum += int(b)
			aSum += int(a)
			count++
		}
		
		// Sliding window across the row
		for x := bounds.Min.X; x < bounds.Max.X; x++ {
			// Set pixel to average
			if count > 0 {
				c := color.RGBA{
					R: uint8(rSum / count),
					G: uint8(gSum / count),
					B: uint8(bSum / count),
					A: uint8(aSum / count),
				}
				blurredImg.Set(x, y, c)
			}
			
			// Remove leftmost pixel from sums
			if x-radius >= bounds.Min.X {
				r, g, b, a := getRGBA(img.At(x-radius, y))
				rSum -= int(r)
				gSum -= int(g)
				bSum -= int(b)
				aSum -= int(a)
				count--
			}
			
			// Add rightmost pixel to sums
			if x+radius+1 < bounds.Max.X {
				r, g, b, a := getRGBA(img.At(x+radius+1, y))
				rSum += int(r)
				gSum += int(g)
				bSum += int(b)
				aSum += int(a)
				count++
			}
		}
	}
	
	// Create a copy for vertical blur
	tempImg := image.NewRGBA(bounds)
	draw.Draw(tempImg, bounds, blurredImg, bounds.Min, draw.Src)
	
	// Apply vertical blur
	for x := bounds.Min.X; x < bounds.Max.X; x++ {
		// Create accumulator for each channel
		var rSum, gSum, bSum, aSum, count int
		
		// Initialize with first pixel
		for i := bounds.Min.Y; i <= bounds.Min.Y+radius && i < bounds.Max.Y; i++ {
			r, g, b, a := getRGBA(tempImg.At(x, i))
			rSum += int(r)
			gSum += int(g)
			bSum += int(b)
			aSum += int(a)
			count++
		}
		
		// Sliding window down the column
		for y := bounds.Min.Y; y < bounds.Max.Y; y++ {
			// Set pixel to average
			if count > 0 {
				c := color.RGBA{
					R: uint8(rSum / count),
					G: uint8(gSum / count),
					B: uint8(bSum / count),
					A: uint8(aSum / count),
				}
				blurredImg.Set(x, y, c)
			}
			
			// Remove topmost pixel from sums
			if y-radius >= bounds.Min.Y {
				r, g, b, a := getRGBA(tempImg.At(x, y-radius))
				rSum -= int(r)
				gSum -= int(g)
				bSum -= int(b)
				aSum -= int(a)
				count--
			}
			
			// Add bottommost pixel to sums
			if y+radius+1 < bounds.Max.Y {
				r, g, b, a := getRGBA(tempImg.At(x, y+radius+1))
				rSum += int(r)
				gSum += int(g)
				bSum += int(b)
				aSum += int(a)
				count++
			}
		}
	}
	
	return blurredImg
}

// applyGaussianBlur applies a Gaussian blur filter with the given sigma
func applyGaussianBlur(img image.Image, sigma float64) image.Image {
	// Calculate kernel size based on sigma (usual rule of thumb: 6*sigma)
	kernelSize := int(math.Ceil(6.0 * sigma))
	if kernelSize%2 == 0 {
		kernelSize++ // Make sure it's odd
	}
	radius := kernelSize / 2
	
	// Create the kernel
	kernel := make([]float64, kernelSize)
	sum := 0.0
	
	// Fill the kernel with Gaussian values
	for i := 0; i < kernelSize; i++ {
		x := float64(i - radius)
		kernel[i] = math.Exp(-(x * x) / (2 * sigma * sigma))
		sum += kernel[i]
	}
	
	// Normalize the kernel
	for i := 0; i < kernelSize; i++ {
		kernel[i] /= sum
	}
	
	bounds := img.Bounds()
	blurredImg := image.NewRGBA(bounds)
	tempImg := image.NewRGBA(bounds)
	
	// Apply horizontal blur
	for y := bounds.Min.Y; y < bounds.Max.Y; y++ {
		for x := bounds.Min.X; x < bounds.Max.X; x++ {
			var rSum, gSum, bSum, aSum float64
			var weightSum float64
			
			for i := -radius; i <= radius; i++ {
				srcX := x + i
				if srcX >= bounds.Min.X && srcX < bounds.Max.X {
					r, g, b, a := getRGBA(img.At(srcX, y))
					weight := kernel[i+radius]
					
					rSum += float64(r) * weight
					gSum += float64(g) * weight
					bSum += float64(b) * weight
					aSum += float64(a) * weight
					weightSum += weight
				}
			}
			
			// Set the pixel
			if weightSum > 0 {
				c := color.RGBA{
					R: uint8(rSum / weightSum),
					G: uint8(gSum / weightSum),
					B: uint8(bSum / weightSum),
					A: uint8(aSum / weightSum),
				}
				tempImg.Set(x, y, c)
			}
		}
	}
	
	// Apply vertical blur
	for y := bounds.Min.Y; y < bounds.Max.Y; y++ {
		for x := bounds.Min.X; x < bounds.Max.X; x++ {
			var rSum, gSum, bSum, aSum float64
			var weightSum float64
			
			for i := -radius; i <= radius; i++ {
				srcY := y + i
				if srcY >= bounds.Min.Y && srcY < bounds.Max.Y {
					r, g, b, a := getRGBA(tempImg.At(x, srcY))
					weight := kernel[i+radius]
					
					rSum += float64(r) * weight
					gSum += float64(g) * weight
					bSum += float64(b) * weight
					aSum += float64(a) * weight
					weightSum += weight
				}
			}
			
			// Set the pixel
			if weightSum > 0 {
				c := color.RGBA{
					R: uint8(rSum / weightSum),
					G: uint8(gSum / weightSum),
					B: uint8(bSum / weightSum),
					A: uint8(aSum / weightSum),
				}
				blurredImg.Set(x, y, c)
			}
		}
	}
	
	return blurredImg
}

// applySobelEdgeDetection applies Sobel edge detection
func applySobelEdgeDetection(img image.Image) image.Image {
	// Convert to grayscale first
	grayImg := applyGrayscale(img)
	
	bounds := grayImg.Bounds()
	edgeImg := image.NewGray(bounds)
	
	// Sobel kernels
	sobelX := [][]int{
		{-1, 0, 1},
		{-2, 0, 2},
		{-1, 0, 1},
	}
	
	sobelY := [][]int{
		{-1, -2, -1},
		{0, 0, 0},
		{1, 2, 1},
	}
	
	// Apply Sobel operator
	for y := bounds.Min.Y + 1; y < bounds.Max.Y-1; y++ {
		for x := bounds.Min.X + 1; x < bounds.Max.X-1; x++ {
			var gx, gy float64
			
			// Apply kernels
			for i := -1; i <= 1; i++ {
				for j := -1; j <= 1; j++ {
					r, _, _, _ := grayImg.At(x+j, y+i).RGBA()
					intensity := float64(r >> 8) // Convert to 8-bit
					
					gx += intensity * float64(sobelX[i+1][j+1])
					gy += intensity * float64(sobelY[i+1][j+1])
				}
			}
			
			// Calculate magnitude
			magnitude := math.Sqrt(gx*gx + gy*gy)
			
			// Normalize to 0-255
			value := uint8(math.Min(255, magnitude))
			edgeImg.SetGray(x, y, color.Gray{Y: value})
		}
	}
	
	return edgeImg
}

// Helper function to extract RGBA values from a color
func getRGBA(c color.Color) (uint8, uint8, uint8, uint8) {
	r, g, b, a := c.RGBA()
	return uint8(r >> 8), uint8(g >> 8), uint8(b >> 8), uint8(a >> 8)
}
