package api

import (
	"net/http"
	"time"
	
	"ancient-script-translator/api/middleware"
)

// SetupRoutes sets up the API routes
func SetupRoutes() http.Handler {
	mux := http.NewServeMux()
	
	// API endpoints
	mux.HandleFunc("/api/process", ProcessImageHandler)
	mux.HandleFunc("/api/algorithms", GetAlgorithmsHandler)
	mux.HandleFunc("/api/health", HealthCheckHandler)
	mux.HandleFunc("/api/translate", TranslateHandler)
	mux.HandleFunc("/api/translators", GetTranslatorsHandler)
	
	// Create middleware chain
	rateLimiter := middleware.NewRateLimiter(100 * time.Millisecond)
	handler := middleware.Recovery(
		middleware.Logger(
			middleware.CORS(
				rateLimiter.Limit(mux),
			),
		),
	)
	
	return handler
}
