package api

import (
	"encoding/json"
	"io"
	"net/http"
	"sync"
	
	"ancient-script-translator/image_processor"
	"ancient-script-translator/translator"
)

// Global translator registry with concurrent access control
var (
	translatorRegistry *translator.TranslatorRegistry
	registryOnce       sync.Once
)

// getTranslatorRegistry returns the singleton translator registry
func getTranslatorRegistry() *translator.TranslatorRegistry {
	registryOnce.Do(func() {
		// Initialize registry
		translatorRegistry = translator.NewTranslatorRegistry()
		
		// Register mock translator
		mockTranslator := translator.NewMockTranslator()
		translatorRegistry.Register(mockTranslator)
	})
	
	return translatorRegistry
}

// ProcessImageHandler handles image processing requests
func ProcessImageHandler(w http.ResponseWriter, r *http.Request) {
	// Only allow POST method
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	
	// Parse form data
	err := r.ParseMultipartForm(10 << 20) // 10 MB max
	if err != nil {
		http.Error(w, "Could not parse form data", http.StatusBadRequest)
		return
	}
	
	// Get algorithm from form
	algorithm := r.FormValue("algorithm")
	if algorithm == "" {
		http.Error(w, "Algorithm parameter is required", http.StatusBadRequest)
		return
	}
	
	// Parse additional parameters
	params := make(map[string]interface{})
	if r.FormValue("params") != "" {
		err = json.Unmarshal([]byte(r.FormValue("params")), &params)
		if err != nil {
			http.Error(w, "Invalid parameters format", http.StatusBadRequest)
			return
		}
	}
	
	// Get file from form
	file, _, err := r.FormFile("image")
	if err != nil {
		http.Error(w, "Image file is required", http.StatusBadRequest)
		return
	}
	defer file.Close()
	
	// Read the file
	fileBytes, err := io.ReadAll(file)
	if err != nil {
		http.Error(w, "Failed to read file", http.StatusInternalServerError)
		return
	}
	
	// Process the image
	processedBytes, err := image_processor.ProcessImage(fileBytes, algorithm, params)
	if err != nil {
		http.Error(w, "Image processing failed: "+err.Error(), http.StatusInternalServerError)
		return
	}
	
	// Send processed image
	w.Header().Set("Content-Type", "image/jpeg") // Default to JPEG
	w.Write(processedBytes)
}

// HealthCheckHandler handles health check requests
func HealthCheckHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"status": "healthy"})
}

// GetAlgorithmsHandler returns the list of available algorithms
func GetAlgorithmsHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	
	algorithms := []map[string]interface{}{
		{
			"id":          "grayscale",
			"name":        "Grayscale",
			"description": "Convert image to grayscale",
			"params":      []string{},
		},
		{
			"id":          "rotate",
			"name":        "Rotate",
			"description": "Rotate image by specified angle",
			"params":      []string{"angle"},
		},
		{
			"id":          "rotate_shear",
			"name":        "Rotate with Shear",
			"description": "Rotate image using three shear matrices",
			"params":      []string{"angle"},
		},
		{
			"id":          "flip",
			"name":        "Flip Vertical",
			"description": "Flip image upside down",
			"params":      []string{},
		},
		{
			"id":          "box_blur",
			"name":        "Box Blur",
			"description": "Apply box blur filter",
			"params":      []string{"radius"},
		},
		{
			"id":          "gaussian_blur",
			"name":        "Gaussian Blur",
			"description": "Apply Gaussian blur filter",
			"params":      []string{"sigma"},
		},
		{
			"id":          "edge_detection",
			"name":        "Edge Detection",
			"description": "Apply Sobel edge detection",
			"params":      []string{},
		},
	}
	
	json.NewEncoder(w).Encode(algorithms)
}

// TranslateHandler handles text translation requests
func TranslateHandler(w http.ResponseWriter, r *http.Request) {
	// Only allow POST method
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	
	// Parse JSON request
	var request struct {
		Text       string `json:"text"`
		Translator string `json:"translator"`
	}
	
	err := json.NewDecoder(r.Body).Decode(&request)
	if err != nil {
		http.Error(w, "Invalid request format", http.StatusBadRequest)
		return
	}
	
	// Validate required fields
	if request.Text == "" {
		http.Error(w, "Text parameter is required", http.StatusBadRequest)
		return
	}
	
	// Get translator (use default if not specified)
	registry := getTranslatorRegistry()
	var translatorInstance translator.Translator
	
	if request.Translator != "" {
		var err error
		translatorInstance, err = registry.Get(request.Translator)
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
	} else {
		// Get the first available translator
		translators := registry.GetAll()
		if len(translators) == 0 {
			http.Error(w, "No translators available", http.StatusInternalServerError)
			return
		}
		translatorInstance = translators[0]
	}
	
	// Perform translation
	result, err := translatorInstance.Translate(request.Text)
	if err != nil {
		http.Error(w, "Translation failed: "+err.Error(), http.StatusInternalServerError)
		return
	}
	
	// Return the result
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(result)
}

// GetTranslatorsHandler returns the list of available translators
func GetTranslatorsHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	
	registry := getTranslatorRegistry()
	translators := registry.GetAll()
	
	// Convert to JSON-friendly format
	response := make([]map[string]interface{}, len(translators))
	for i, t := range translators {
		response[i] = map[string]interface{}{
			"name":      t.GetName(),
			"languages": t.GetLanguages(),
		}
	}
	
	json.NewEncoder(w).Encode(response)
}
